# 云南大学研究生学位论文 LaTeX 模板



原大佬在这里

- [Astro-Lee/YNUthesis: LaTeX thesis template for Yunnan University (github.com)](https://github.com/Astro-Lee/YNUthesis)
- **原模板**封面的标题是`居中对齐`, **研究生院**发的通知为`左对齐`



[![Compiling LaTeX template](https://github.com/Astro-Lee/YNUthesis/actions/workflows/Compiling%20LaTeX%20template.yml/badge.svg)](https://github.com/Astro-Lee/YNUthesis/actions/workflows/Compiling%20LaTeX%20template.yml)

- 本模板正处于开发阶段。

- 本模板根据[《云南大学研究生学位论文写作规范》](http://www.grs.ynu.edu.cn/info/1037/1540.htm)编写，**个人能力、精力有限，不保证完全符合规范！此外，该模板未经学校官方核准，如有顾虑，请不要使用！**

- [Overleaf](https://cn.overleaf.com/latex/templates?q=%E4%BA%91%E5%8D%97%E5%A4%A7%E5%AD%A6)

# 贡献

用户若有建议或需求，欢迎提交 [issues](https://github.com/Astro-Lee/YNUthesis/issues)、[pull requests](https://github.com/Astro-Lee/YNUthesis/pulls) 或 [discussions](https://github.com/Astro-Lee/YNUthesis/discussions)。

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=Astro-Lee/YNU-thesis-bachelor,Astro-Lee/YNUthesis&type=Date)](https://star-history.com/#Astro-Lee/YNU-thesis-bachelor&Astro-Lee/YNUthesis&Date)

# 致谢
- [stone-zeng/fduthesis](https://github.com/stone-zeng/fduthesis)
---
- Email: liruizhi0871[AT]gmail.com
- Copyright (C) 2023 by Rui-Zhi Li.
